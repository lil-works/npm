<?php

// OperatorBundle:breakdown:show.html.twig
return array (
);
