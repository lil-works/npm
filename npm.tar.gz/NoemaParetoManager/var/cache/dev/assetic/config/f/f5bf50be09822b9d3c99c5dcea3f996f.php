<?php

// ManagerBundle:Descriptor:show.html.twig
return array (
);
