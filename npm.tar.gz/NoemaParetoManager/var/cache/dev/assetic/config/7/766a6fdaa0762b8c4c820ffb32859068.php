<?php

// ManagerBundle:Descriptor:index.html.twig
return array (
);
