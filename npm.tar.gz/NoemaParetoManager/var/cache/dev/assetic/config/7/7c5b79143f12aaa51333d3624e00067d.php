<?php

// ManagerBundle:descriptor:index.html.twig
return array (
);
