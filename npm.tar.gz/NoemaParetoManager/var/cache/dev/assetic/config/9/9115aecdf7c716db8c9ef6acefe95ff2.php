<?php

// AnalyzerBundle:Default:descriptorBar2.html.twig
return array (
);
