<?php

// AnalyzerBundle:Default:descriptorBar.html.twig
return array (
);
