<?php

// ManagerBundle:Descriptor:edit.html.twig
return array (
);
