<?php

// ManagerBundle:Descriptor:new.html.twig
return array (
);
