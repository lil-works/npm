<?php

// ManagerBundle:synonym:new.html.twig
return array (
);
