<?php

// ManagerBundle:synonym:edit.html.twig
return array (
);
