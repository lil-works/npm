<?php

// ManagerBundle:descriptor:edit.html.twig
return array (
);
