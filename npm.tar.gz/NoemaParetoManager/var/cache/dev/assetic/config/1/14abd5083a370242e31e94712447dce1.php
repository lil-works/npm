<?php

// ManagerBundle:Default:menu.html.twig
return array (
);
