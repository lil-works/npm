<?php

// ManagerBundle:synonym:show.html.twig
return array (
);
