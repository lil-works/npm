<?php

// ManagerBundle:synonym:index.html.twig
return array (
);
