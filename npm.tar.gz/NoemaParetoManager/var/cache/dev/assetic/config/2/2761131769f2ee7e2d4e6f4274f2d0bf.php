<?php

// ManagerBundle:descriptor:new.html.twig
return array (
);
