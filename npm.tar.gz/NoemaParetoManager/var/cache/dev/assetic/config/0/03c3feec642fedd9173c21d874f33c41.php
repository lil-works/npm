<?php

// OperatorBundle:default:menu.html.twig
return array (
);
