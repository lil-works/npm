<?php

// ManagerBundle:descriptor:show.html.twig
return array (
);
