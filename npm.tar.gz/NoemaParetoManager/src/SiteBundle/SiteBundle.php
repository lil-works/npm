<?php

namespace SiteBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SiteBundle extends Bundle
{
}
