<?php

namespace OperatorBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OperatorBundle extends Bundle
{
}
