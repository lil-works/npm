<?php

namespace ManagerBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ManagerBundle extends Bundle
{
}
